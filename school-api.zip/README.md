# School Management API

A RESTful API built using Node.js, Express.js, and MySQL for managing schools and listing them by proximity.

## Features
- Add a new school with name, address, latitude, and longitude
- List schools sorted by distance to a user location

## Setup

### 1. Install dependencies
```bash
npm install
```

### 2. Configure Environment Variables
Create a `.env` file using `.env.example` and add your MySQL credentials:
```env
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=yourpassword
DB_NAME=schooldb
```

### 3. Run the API
```bash
npm start
```

## API Endpoints

### POST `/addSchool`
Add a new school
```json
{
  "name": "ABC School",
  "address": "Main St",
  "latitude": 12.34,
  "longitude": 56.78
}
```

### GET `/listSchools?latitude=12.34&longitude=56.78`
List schools sorted by distance
